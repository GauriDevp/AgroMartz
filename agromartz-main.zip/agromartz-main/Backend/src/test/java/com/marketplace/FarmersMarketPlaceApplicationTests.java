package com.marketplace;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmersMarketPlaceApplicationTests {

	@Test
	void contextLoads() {
	}

}
