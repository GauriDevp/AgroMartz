package com.marketplace;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmersMarketPlaceApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(FarmersMarketPlaceApplication.class, args);
	}
	
}
